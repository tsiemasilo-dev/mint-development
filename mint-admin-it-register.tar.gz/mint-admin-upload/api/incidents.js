// Vercel serverless function — IT Incident Register API
// Handles GET /api/incidents, POST /api/incidents, PATCH /api/incidents?id=<uuid>
// Uses Supabase service role directly (same pattern as other MyMintAdmin API routes).

module.exports = async (req, res) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');

  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    return res.end();
  }

  const supabaseUrl = process.env.SUPABASE_URL;
  const serviceKey  = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !serviceKey) {
    res.statusCode = 500;
    return res.end(JSON.stringify({ error: 'Supabase not configured' }));
  }

  const sbH = {
    apikey: serviceKey,
    Authorization: `Bearer ${serviceKey}`,
    'Content-Type': 'application/json',
    Prefer: 'return=representation',
  };

  const base = `${supabaseUrl}/rest/v1/it_incidents`;

  // ── GET — list incidents ────────────────────────────────────────────────────
  if (req.method === 'GET') {
    try {
      const params = new URLSearchParams();
      params.set('select', '*');
      params.set('order', 'start_time.desc');
      if (req.query && req.query.status)   params.set('status',   `eq.${req.query.status}`);
      if (req.query && req.query.severity) params.set('severity', `eq.${req.query.severity}`);
      const r = await fetch(`${base}?${params}`, { headers: sbH });
      const data = await r.json();
      if (!r.ok) throw new Error(data.message || r.status);
      res.statusCode = 200;
      return res.end(JSON.stringify({ incidents: data }));
    } catch (e) {
      res.statusCode = 500;
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  // ── POST — create incident ──────────────────────────────────────────────────
  if (req.method === 'POST') {
    try {
      const body = req.body || {};
      const { title, affected_service, severity, start_time, description, created_by } = body;
      if (!title || !affected_service || !severity) {
        res.statusCode = 400;
        return res.end(JSON.stringify({ error: 'title, affected_service, and severity are required' }));
      }
      const validSeverities = ['low', 'medium', 'high', 'critical'];
      if (!validSeverities.includes(severity)) {
        res.statusCode = 400;
        return res.end(JSON.stringify({ error: `severity must be one of: ${validSeverities.join(', ')}` }));
      }
      const payload = {
        title: title.trim(),
        affected_service: affected_service.trim(),
        severity,
        status: 'open',
        start_time: start_time || new Date().toISOString(),
        description: description || null,
        created_by: created_by || null,
      };
      const r = await fetch(base, {
        method: 'POST',
        headers: sbH,
        body: JSON.stringify(payload),
      });
      const data = await r.json();
      if (!r.ok) throw new Error((Array.isArray(data) ? data[0]?.message : data?.message) || r.status);
      const incident = Array.isArray(data) ? data[0] : data;
      res.statusCode = 201;
      return res.end(JSON.stringify({ incident }));
    } catch (e) {
      res.statusCode = 500;
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  // ── PATCH — update / resolve incident (/api/incidents?id=uuid) ──────────────
  if (req.method === 'PATCH') {
    try {
      const id = req.query && req.query.id;
      if (!id) {
        res.statusCode = 400;
        return res.end(JSON.stringify({ error: 'id query param required' }));
      }

      // Fetch existing to calculate downtime
      const existingR = await fetch(`${base}?id=eq.${id}&select=*`, { headers: sbH });
      const existing = await existingR.json();
      if (!existing.length) {
        res.statusCode = 404;
        return res.end(JSON.stringify({ error: 'Incident not found' }));
      }
      const inc = existing[0];

      const body = req.body || {};
      const { status, root_cause, resolution_notes, resolved_time } = body;
      const validStatuses = ['open', 'investigating', 'resolved'];
      if (status && !validStatuses.includes(status)) {
        res.statusCode = 400;
        return res.end(JSON.stringify({ error: `status must be one of: ${validStatuses.join(', ')}` }));
      }

      const update = { updated_at: new Date().toISOString() };
      if (status !== undefined) update.status = status;
      if (root_cause !== undefined) update.root_cause = root_cause;
      if (resolution_notes !== undefined) update.resolution_notes = resolution_notes;

      if (status === 'resolved') {
        const resolvedAt = resolved_time ? new Date(resolved_time) : new Date();
        const startedAt  = new Date(inc.start_time);
        update.resolved_time = resolvedAt.toISOString();
        update.downtime_duration_minutes = Math.max(0, Math.round((resolvedAt - startedAt) / 60000));
      }

      const r = await fetch(`${base}?id=eq.${id}`, {
        method: 'PATCH',
        headers: sbH,
        body: JSON.stringify(update),
      });
      const data = await r.json();
      if (!r.ok) throw new Error((Array.isArray(data) ? data[0]?.message : data?.message) || r.status);
      const incident = Array.isArray(data) ? data[0] : data;
      res.statusCode = 200;
      return res.end(JSON.stringify({ incident }));
    } catch (e) {
      res.statusCode = 500;
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  res.statusCode = 405;
  res.end(JSON.stringify({ error: 'Method not allowed' }));
};
